# Constellation Maker
### Project submitted to McHacks 2015.
Inspired by the planetarium feature in Animal Crossing: Wild World, it randomly populates the page with twinkling stars which you can draw constellations in and then download.
Uses:
- Semantic UI
- html2canvas
